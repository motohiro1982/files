AWS PV Driver Package
=====================
Release 8.4.3


Component Versions
==================
XenBus    8.3.0.7
XenIface  8.2.7.5
XenNet    8.2.5.32
XenVBD    8.4.1.6
XenVif    8.2.9.8


Prerequisites
=============
- .NET Framework 4.5
- Windows Server 2012, 2012 R2, 2016, 2019, or 2022.


Before You Start
================
- This upgrade automatically reboots the system while updating critical system
  components. Therefore, we strongly recommend that you back up all critical
  data and stop all applications before performing the upgrade.
- Please ensure no reboots are pending before performing the upgrade.
- If the instance is currently running the Citrix PV Driver, please be aware
  that all disks except the system disk (usually C:) will be taken offline
  during the upgrade process. It is recommended to manually take all non-system
  disks offline before proceeding.


Installation
============
- Run AWSPVDriverSetup.msi or install.ps1 as an Administrator to install.
- Wait for the instance to reboot (~5 minutes, depending on the instance type).
- The instance may become unreachable during the upgrade, but will come back
  online after the upgrade finishes.
- Do not manually stop/start/reboot the instance while the upgrade is in
  progress.


Silent Install
==============
- Note that usage of this option implies acceptance of the EULA that would
  otherwise be displayed as part of an interactive install.
- Run AWSPVDriverSetup.msi or install.ps1 with the 'quiet' option. For example:
  'AWSPVDriverSetup.msi /quiet'
  or
  '.\install.ps1 -Quiet'


Reboot
======
- Reboots happen automatically, but you can specify the 'norestart/NoReboot'
  option to stop the reboot. For example:
  'AWSPVDriverSetup.msi /quiet /norestart'
  or
  '.\install.ps1 -Quiet -NoReboot'


Verification
============
- After a successful install you can run the following command from an elevated
  command prompt to output the driver package version:
    reg query HKLM\SOFTWARE\Amazon\PVDriver
- If the upgrade fails please review the log file which, by default, can be
  found here:
    C:\Program Files\Amazon\XenTools\AWSPVDriverMSI.log


Known Issues
============
- If you install the upgrade into a new directory, the old driver directories
  are not deleted.

